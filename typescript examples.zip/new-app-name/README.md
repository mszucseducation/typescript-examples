
npm install --save styled-components
npm install --save-dev babel-plugin-styled-components