import styled from "styled-components";

const Title = styled.h1`
    color: #ABC123
`;

const SecondaryTitle = styled.h2`
    color: #567ABC
`;

export {Title, SecondaryTitle}