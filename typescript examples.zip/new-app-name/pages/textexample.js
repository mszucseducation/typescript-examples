import styled from 'styled-components';
import {Title, SecondaryTitle} from './textexamplestyles'


export default function Buttonexample() {
    return (
        <div>
            <Title>Primary</Title>

            <SecondaryTitle>Secondary</SecondaryTitle>
        </div>
    )
}

