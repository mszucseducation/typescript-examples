import styled from 'styled-components';

export const Button = styled.button`
    cursor: pointer;
    padding: 15px 22px;
    border-radius: 24px;
    border: none;
    font-weight: 500;
    color: #fff;
    background: ${(props) => props.secondary ? "#f00" : "#00a8ff"};
`;

export default function Buttonexample() {
    return (
        <div>
        <Button>Primary</Button>
        <Button secondary>Secondary</Button>
        </div>
    )
}