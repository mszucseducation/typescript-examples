import { useEffect, useState } from "react";

export default function ExampleThree() {

    const data = ["sunny", "rainy", "cloudy"]
    const [number, setNumber] = useState();

    useEffect(() => {
        setNumber(Math.floor(Math.random() * 2));
    }, [])
    

    if(data[number] === "sunny") {
        return (
            <>
                Time to go outside!
            </>
        )
    } else {
        return (
            <>
                Stay inside!
            </>
        )
    }
    
}