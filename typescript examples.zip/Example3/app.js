// you shouldn't do: const person: object
// TS notation for object represented at {}
var person = {
    name: "John",
    age: 30
};
console.log(person);
console.log(person.name);
